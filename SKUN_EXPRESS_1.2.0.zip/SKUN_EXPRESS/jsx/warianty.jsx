﻿#target photoshop

/*
 * SKUN - Warianty grafik v1.0
 * Photoshop / ExtendScript (ES3), Windows i macOS.
 *
 * URUCHOMIENIE: Plik > Skrypty > Przegladaj...
 *
 * STRUKTURA: bezposrednio w kazdym obszarze kompozycji umiesc grupy
 * warstw: jedna stala i dowolna liczbe zmiennych. Kazda grupa jest
 * jednym skladnikiem. Widocznosc wewnatrz grup zostaje zachowana.
 *
 * EKSPORT: stala+A, stala+B, stala+C i opcjonalnie sama stala.
 * Kazda zmienna jest eksportowana oddzielnie ze stala grafika.
 * Kolejnosc warstw pozostaje taka jak w dokumencie.
 * Warstwy luzem i niewybrane grupy sa pomijane w eksporcie.
 *
 * Eksport: JPG, sRGB, 8 bitow, wymiary obszaru w pikselach.
 * Wszystkie zmiany dokumentu odbywaja sie na kopiach tymczasowych.
 * Oryginalny PSD nie jest zapisywany ani modyfikowany.
 *
 * Mechanika wspolrzednych obszarow: artboard.artboardRect oraz
 * rulerOriginH/V po splaszczeniu (w jednostkach 1/65536 piksela).
 * Referencje implementacyjne:
 * https://github.com/Adobe-CEP/CEP-Resources/tree/master/Documentation
 * https://github.com/antoniocosta/photoshopscripts
 */

(function () {
    var TITLE = "SKUN | Warianty grafik v1.0";
    var sourceDoc = null;
    var workingDoc = null;
    var renderDoc = null;
    var progress = null;
    var oldUnits = null;
    var oldDialogs = null;
    var prefsChanged = false;
    var savedCount = 0;
    var totalCount = 0;
    var activeTask = "Uruchamianie";
    var settings = null;
    var wasCancelled = false;
    var failure = null;
    var cleanupWarnings = [];

    // BEGIN PURE CORE -- independent of the Photoshop DOM.
    var Core = (function () {
        function trim(s) {
            return String(s).replace(/^\s+|\s+$/g, "");
        }

        function safeToken(s, maxLength) {
            var value = trim(s).replace(/[\x00-\x1F\x7F\\\/:*?"<>|]/g, "_");
            value = value.replace(/\s+/g, "_").replace(/_+/g, "_");
            value = value.replace(/^[. ]+|[. ]+$/g, "");
            if (!value) { value = "bez_nazwy"; }
            if (/^(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])(?:\.|$)/i.test(value)) {
                value = "_" + value;
            }
            if (maxLength && value.length > maxLength) {
                value = value.substring(0, maxLength).replace(/[. ]+$/g, "");
                // Do not split a Unicode surrogate pair at the filename boundary.
                if (value.length && /[\uD800-\uDBFF]/.test(value.charAt(value.length - 1))) {
                    value = value.substring(0, value.length - 1);
                }
            }
            return value || "bez_nazwy";
        }

        function pad(n, width) {
            var s = String(n);
            while (s.length < width) { s = "0" + s; }
            return s;
        }

        function variantCount(n, includeBase) {
            return n + (includeBase ? 1 : 0);
        }

        function eachVariant(n, includeBase, visit) {
            if (includeBase && visit([]) === false) { return false; }
            for (var i = 0; i < n; i++) {
                if (visit([i]) === false) { return false; }
            }
            return true;
        }

        function cropBounds(rect, origin) {
            return [rect[0] - origin[0], rect[1] - origin[1],
                    rect[2] - origin[0], rect[3] - origin[1]];
        }

        function filename(prefix, boardNumber, boardName, sequence, names) {
            var head = prefix ? safeToken(prefix, 36) + "__" : "";
            head += "AB" + pad(boardNumber, 2) + "_" + safeToken(boardName, 40);
            head += "__" + pad(sequence, 5) + "__";
            var tail = names.length ? names.join("+") : "samo_tlo";
            return head + safeToken(tail, 72);
        }

        return {trim: trim, safeToken: safeToken, pad: pad,
                variantCount: variantCount, eachVariant: eachVariant,
                cropBounds: cropBounds, filename: filename};
    }());
    // END PURE CORE

    function sid(s) { return stringIDToTypeID(s); }

    function descNumber(desc, key) {
        var id = sid(key);
        var kind = desc.getType(id);
        if (kind === DescValueType.UNITDOUBLE) { return desc.getUnitDoubleValue(id); }
        if (kind === DescValueType.DOUBLETYPE) { return desc.getDouble(id); }
        if (kind === DescValueType.INTEGERTYPE) { return desc.getInteger(id); }
        throw new Error("Nieobsługiwany typ współrzędnej: " + key);
    }

    function layerDescriptor(layer) {
        var ref = new ActionReference();
        ref.putIdentifier(sid("layer"), layer.id);
        return executeActionGet(ref);
    }

    function isArtboard(layer) {
        if (layer.typename !== "LayerSet") { return false; }
        var d = layerDescriptor(layer);
        return d.hasKey(sid("artboardEnabled")) && d.getBoolean(sid("artboardEnabled"));
    }

    function artboardRect(layer) {
        var d = layerDescriptor(layer).getObjectValue(sid("artboard"));
        var r = d.getObjectValue(sid("artboardRect"));
        var result = [descNumber(r, "left"), descNumber(r, "top"),
                      descNumber(r, "right"), descNumber(r, "bottom")];
        if (!(result[2] > result[0] && result[3] > result[1])) {
            throw new Error("Obszar „" + layer.name + "” ma nieprawidłowe wymiary.");
        }
        return result;
    }

    function activeRulerOrigin() {
        var ref = new ActionReference();
        ref.putEnumerated(sid("document"), sid("ordinal"), sid("targetEnum"));
        var d = executeActionGet(ref);
        if (!d.hasKey(sid("rulerOriginH")) || !d.hasKey(sid("rulerOriginV"))) {
            throw new Error("Photoshop nie udostępnił początku współrzędnych dokumentu.");
        }
        return [d.getInteger(sid("rulerOriginH")) / 65536,
                d.getInteger(sid("rulerOriginV")) / 65536];
    }

    function directGroups(board) {
        var result = [];
        var i, layer;
        for (i = 0; i < board.layers.length; i++) {
            layer = board.layers[i];
            if (layer.typename === "LayerSet" && !isArtboard(layer)) {
                result.push({name: layer.name, layerIndex: i});
            }
        }
        return result;
    }

    function collectArtboards(container, parentPath, output) {
        var i, layer, path, groups, rect;
        for (i = 0; i < container.layers.length; i++) {
            layer = container.layers[i];
            if (layer.typename !== "LayerSet") { continue; }
            path = parentPath.concat([i]);
            if (isArtboard(layer)) {
                groups = directGroups(layer);
                rect = artboardRect(layer);
                output.push({name: layer.name, path: path, groups: groups,
                             width: Math.round(rect[2] - rect[0]),
                             height: Math.round(rect[3] - rect[1]),
                             omitted: layer.layers.length - groups.length,
                             number: output.length + 1});
            } else {
                collectArtboards(layer, path, output);
            }
        }
    }

    function addText(parent, message, height) {
        var t = parent.add("statictext", undefined, message, {multiline: true});
        t.preferredSize = [570, height || 38];
        t.alignment = "fill";
        return t;
    }

    function configArtboard(board, current, count) {
        var w = new Window("dialog", TITLE);
        w.orientation = "column";
        w.alignChildren = "fill";
        w.spacing = 9;
        w.margins = 16;
        addText(w, "Obszar " + current + " z " + count + ": " + board.name +
                   "\n" + board.width + " × " + board.height + " px", 42);

        if (!board.groups.length) {
            addText(w, "Ten obszar nie zawiera grup warstw do wyboru. Umieść tło i zmienne grafiki w osobnych grupach bezpośrednio w obszarze kompozycji.", 62);
            var emptyButtons = w.add("group");
            emptyButtons.alignment = "right";
            emptyButtons.add("button", undefined, "Anuluj wszystko", {name: "cancel"});
            var skipEmpty = emptyButtons.add("button", undefined, "Pomiń obszar", {name: "ok"});
            skipEmpty.onClick = function () { w.close(3); };
            return w.show() === 3 ? {skip: true} : null;
        }

        var fixedPanel = w.add("panel", undefined, "Grafika stała — jedna grupa");
        fixedPanel.orientation = "column";
        fixedPanel.alignChildren = "fill";
        fixedPanel.margins = 12;
        var fixed = fixedPanel.add("dropdownlist", undefined, []);
        fixed.preferredSize.width = 550;
        var i;
        for (i = 0; i < board.groups.length; i++) {
            fixed.add("item", (i + 1) + ". " + board.groups[i].name);
        }
        fixed.selection = board.groups.length - 1;
        addText(fixedPanel, "Domyślnie wybrana jest najniższa grupa w panelu Warstwy.", 20);

        var variablePanel = w.add("panel", undefined, "Grafiki zmienne — zaznacz grupy");
        variablePanel.orientation = "column";
        variablePanel.alignChildren = "fill";
        variablePanel.margins = 12;
        variablePanel.spacing = 6;

        // Paged checkboxes keep the dialog usable on small screens and long PSDs.
        var PAGE_SIZE = 7;
        var page = 0;
        var pageCount = Math.ceil(board.groups.length / PAGE_SIZE);
        var selected = [];
        for (i = 0; i < board.groups.length; i++) {
            selected[i] = i !== fixed.selection.index;
        }
        var rows = [];
        var rowCount = Math.min(PAGE_SIZE, board.groups.length);
        for (i = 0; i < rowCount; i++) {
            var cb = variablePanel.add("checkbox", undefined, " ");
            cb.preferredSize = [550, 21];
            cb.groupIndex = -1;
            cb.onClick = function () {
                if (this.groupIndex >= 0) { selected[this.groupIndex] = this.value; }
                updateCount();
            };
            rows.push(cb);
        }
        var toolsRow = variablePanel.add("group");
        var allBtn = toolsRow.add("button", undefined, "Zaznacz wszystkie");
        var noneBtn = toolsRow.add("button", undefined, "Odznacz wszystkie");
        var prev = toolsRow.add("button", undefined, "<");
        prev.preferredSize.width = 30;
        var pageText = toolsRow.add("statictext", undefined, "1 / 1");
        pageText.preferredSize.width = 56;
        var next = toolsRow.add("button", undefined, ">");
        next.preferredSize.width = 30;
        prev.visible = next.visible = pageText.visible = pageCount > 1;

        var includeBase = w.add("checkbox", undefined, "Zapisz również samą grafikę stałą (tło)");
        includeBase.value = true;
        var countText = addText(w, " ", 22);
        var note = "Każda grupa jest jednym składnikiem. Widoczność warstw wewnątrz grup i kolejność nakładania pozostają takie jak w PSD.";
        if (board.omitted) {
            note += "\nWarstwy poza tymi grupami: " + board.omitted + " — będą pominięte.";
        }
        addText(w, note, board.omitted ? 58 : 40);

        var buttons = w.add("group");
        buttons.alignment = "right";
        buttons.add("button", undefined, "Anuluj wszystko", {name: "cancel"});
        var skip = buttons.add("button", undefined, "Pomiń obszar");
        var ok = buttons.add("button", undefined,
                             current < count ? "Dalej" : "Ustawienia zapisu", {name: "ok"});
        var answer = null;

        function selectedVariables() {
            var result = [];
            var j;
            for (j = 0; j < selected.length; j++) {
                if (selected[j] && j !== fixed.selection.index) { result.push(j); }
            }
            return result;
        }

        function updateCount() {
            var n = selectedVariables().length;
            var total = Core.variantCount(n, includeBase.value);
            countText.text = "Do zapisania: " + total + " JPG — " + n + " zmiennych" +
                (includeBase.value ? " + samo tło." : ".");
            ok.enabled = total > 0;
        }

        function refreshRows() {
            var j, index, text;
            for (j = 0; j < rows.length; j++) {
                index = page * PAGE_SIZE + j;
                rows[j].groupIndex = index < board.groups.length ? index : -1;
                rows[j].visible = index < board.groups.length;
                if (index < board.groups.length) {
                    text = (index + 1) + ". " + board.groups[index].name;
                    if (index === fixed.selection.index) { text += "  [STAŁA]"; }
                    rows[j].text = text.length > 77 ? text.substring(0, 74) + "..." : text;
                    rows[j].helpTip = text;
                    rows[j].enabled = index !== fixed.selection.index;
                    rows[j].value = selected[index] && index !== fixed.selection.index;
                }
            }
            pageText.text = (page + 1) + " / " + pageCount;
            prev.enabled = page > 0;
            next.enabled = page < pageCount - 1;
            updateCount();
        }

        fixed.onChange = function () {
            selected[fixed.selection.index] = false;
            refreshRows();
        };
        allBtn.onClick = function () {
            for (var j = 0; j < selected.length; j++) { selected[j] = j !== fixed.selection.index; }
            refreshRows();
        };
        noneBtn.onClick = function () {
            for (var j = 0; j < selected.length; j++) { selected[j] = false; }
            refreshRows();
        };
        prev.onClick = function () { if (page > 0) { page--; refreshRows(); } };
        next.onClick = function () { if (page < pageCount - 1) { page++; refreshRows(); } };
        includeBase.onClick = updateCount;
        skip.onClick = function () { w.close(3); };
        ok.onClick = function () {
            var chosen = selectedVariables();
            var n = Core.variantCount(chosen.length, includeBase.value);
            if (n < 1) { return; }
            answer = {board: board, fixed: fixed.selection.index, variables: chosen,
                      includeBase: includeBase.value, count: n};
            w.close(1);
        };
        refreshRows();
        w.center();
        var response = w.show();
        if (response === 3) { return {skip: true}; }
        return response === 1 ? answer : null;
    }

    function outputDialog(plans, total) {
        var w = new Window("dialog", TITLE + " — zapis JPG");
        w.orientation = "column";
        w.alignChildren = "fill";
        w.margins = 16;
        w.spacing = 10;
        addText(w, "Obszary do eksportu: " + plans.length + ". Łącznie: " + total + " JPG.", 24);
        var summary = w.add("listbox", undefined, []);
        summary.preferredSize = [590, Math.min(130, Math.max(45, plans.length * 22 + 8))];
        for (var i = 0; i < plans.length; i++) {
            summary.add("item", plans[i].board.name + "  —  " + plans[i].count + " JPG");
        }

        w.add("statictext", undefined, "Folder zapisu:");
        var folderRow = w.add("group");
        folderRow.alignChildren = ["fill", "center"];
        var folderText = folderRow.add("edittext", undefined, "");
        folderText.preferredSize.width = 455;
        var browse = folderRow.add("button", undefined, "Wybierz...");
        var pickedFolder = null;
        browse.onClick = function () {
            var candidate = pickedFolder ? pickedFolder.selectDlg("Wybierz folder na pliki JPG") :
                                          Folder.selectDialog("Wybierz folder na pliki JPG");
            if (candidate) { pickedFolder = candidate; folderText.text = candidate.fsName; }
        };

        w.add("statictext", undefined, "Prefiks nazw plików (opcjonalny):");
        var prefix = w.add("edittext", undefined, "");
        prefix.characters = 50;
        prefix.helpTip = "Np. tytuł książki. Puste pole oznacza nazwy bez prefiksu.";

        var qualityRow = w.add("group");
        qualityRow.add("statictext", undefined, "Jakość JPG:");
        var quality = qualityRow.add("dropdownlist", undefined, []);
        for (i = 1; i <= 12; i++) { quality.add("item", String(i)); }
        quality.selection = 11;
        qualityRow.add("statictext", undefined, "12 = najwyższa");
        addText(w, "sRGB / 8 bitów / wymiary obszaru kompozycji.\nNazwy zawierają obszar, numer wariantu i nazwy grup zmiennych.", 42);
        addText(w, "Jeśli plik już istnieje, nowy otrzyma kolejny dopisek. Eksport zacznie się po kliknięciu przycisku poniżej.", 40);

        var buttons = w.add("group");
        buttons.alignment = "right";
        buttons.add("button", undefined, "Anuluj", {name: "cancel"});
        var go = buttons.add("button", undefined, "Eksportuj " + total + " JPG", {name: "ok"});
        var result = null;
        go.onClick = function () {
            var path = Core.trim(folderText.text);
            if (!path) {
                alert("Wybierz folder zapisu.", TITLE);
                folderText.active = true;
                return;
            }
            var folder = new Folder(path);
            if (!folder.exists) {
                alert("Folder nie istnieje. Wybierz istniejący folder przyciskiem „Wybierz...”.", TITLE);
                return;
            }
            result = {folder: folder, prefix: Core.trim(prefix.text),
                      quality: quality.selection.index + 1};
            w.close(1);
        };
        w.center();
        return w.show() === 1 ? result : null;
    }

    function makeProgress(total) {
        var p = new Window("palette", TITLE);
        p.orientation = "column";
        p.alignChildren = "fill";
        p.margins = 16;
        p.status = p.add("statictext", undefined, "Przygotowywanie kopii dokumentu...");
        p.status.preferredSize.width = 560;
        p.detail = p.add("statictext", undefined, " ");
        p.detail.preferredSize.width = 560;
        p.bar = p.add("progressbar", undefined, 0, total);
        p.bar.preferredSize = [560, 15];
        p.cancelled = false;
        p.allowClose = false;
        var cancel = p.add("button", undefined, "Przerwij eksport");
        cancel.alignment = "right";
        cancel.onClick = function () {
            p.cancelled = true;
            cancel.enabled = false;
            p.status.text = "Przerywanie po bieżącej operacji...";
        };
        p.onClose = function () {
            if (p.allowClose) { return true; }
            p.cancelled = true;
            return false;
        };
        p.center();
        p.show();
        p.update();
        return p;
    }

    function checkCancel() {
        if (progress) {
            progress.update();
            if (progress.cancelled) { throw {skunCancelled: true}; }
        }
    }

    function showProgress(boardName, detail) {
        if (!progress) { return; }
        progress.status.text = savedCount + " / " + totalCount + " JPG  —  " + boardName;
        progress.detail.text = detail.length > 90 ? detail.substring(0, 87) + "..." : detail;
        progress.bar.value = savedCount;
        progress.update();
        checkCancel();
    }

    function setVisible(layer, value) {
        if (layer.visible !== value) { layer.visible = value; }
    }

    function isolateBoard(doc, path) {
        var container = doc;
        for (var depth = 0; depth < path.length; depth++) {
            if (path[depth] >= container.layers.length) { throw new Error("Nie znaleziono obszaru w kopii dokumentu."); }
            for (var i = 0; i < container.layers.length; i++) {
                setVisible(container.layers[i], i === path[depth]);
            }
            container = container.layers[path[depth]];
        }
        if (!isArtboard(container)) { throw new Error("Wybrana grupa nie jest obszarem kompozycji."); }
        return container;
    }

    function applyCombination(board, plan, combo) {
        var visibleIndices = {};
        var i, groupIndex;
        visibleIndices["L" + plan.board.groups[plan.fixed].layerIndex] = true;
        for (i = 0; i < combo.length; i++) {
            groupIndex = plan.variables[combo[i]];
            visibleIndices["L" + plan.board.groups[groupIndex].layerIndex] = true;
        }
        for (i = 0; i < board.layers.length; i++) {
            setVisible(board.layers[i], visibleIndices["L" + i] === true);
        }
    }

    function groupNames(plan, combo) {
        var names = [];
        for (var i = 0; i < combo.length; i++) {
            names.push(plan.board.groups[plan.variables[combo[i]]].name);
        }
        return names;
    }

    function childFile(folder, basename) {
        // Encode the final path component: literal % and # in group names stay literal.
        return new File(folder.absoluteURI + "/" + encodeURIComponent(basename));
    }

    function availableFile(folder, stem) {
        var f = childFile(folder, stem + ".jpg");
        var suffix = 2;
        while (f.exists) {
            f = childFile(folder, stem + "__" + suffix + ".jpg");
            suffix++;
        }
        return f;
    }

    function closeTemp(doc, label) {
        if (!doc) { return; }
        try {
            app.activeDocument = doc;
            doc.close(SaveOptions.DONOTSAVECHANGES);
        } catch (e) {
            cleanupWarnings.push("Nie udało się zamknąć kopii „" + label + "”. Możesz zamknąć ją bez zapisywania.");
        }
    }

    function saveVariant(work, rect, file, quality) {
        checkCancel();
        app.activeDocument = work;
        activeTask = "Tworzenie kopii do JPG";
        renderDoc = work.duplicate("_SKUN_JPG_TYMCZASOWY_", false);
        try {
            app.activeDocument = renderDoc;
            // Rasterize all masks, group blends and artboard backgrounds in source space.
            activeTask = "Spłaszczanie kopii";
            renderDoc.flatten();
            var origin = activeRulerOrigin();
            var bounds = Core.cropBounds(rect, origin);
            var region = [];
            for (var i = 0; i < 4; i++) { region.push(new UnitValue(bounds[i], "px")); }
            activeTask = "Przycinanie do obszaru kompozycji";
            renderDoc.crop(region);
            var expectedW = Math.round(rect[2] - rect[0]);
            var expectedH = Math.round(rect[3] - rect[1]);
            if (Math.round(renderDoc.width.as("px")) !== expectedW ||
                Math.round(renderDoc.height.as("px")) !== expectedH) {
                throw new Error("Wymiary po przycięciu różnią się od wymiarów obszaru (" + expectedW + " × " + expectedH + " px).");
            }
            checkCancel();
            activeTask = "Konwersja do sRGB";
            renderDoc.convertProfile("sRGB IEC61966-2.1", Intent.RELATIVECOLORIMETRIC, true, true);
            if (renderDoc.mode !== DocumentMode.RGB) {
                throw new Error("Nie udało się uzyskać trybu RGB po konwersji do sRGB.");
            }
            if (renderDoc.bitsPerChannel !== BitsPerChannelType.EIGHT) {
                renderDoc.bitsPerChannel = BitsPerChannelType.EIGHT;
            }
            var options = new JPEGSaveOptions();
            options.quality = quality;
            options.embedColorProfile = true;
            options.formatOptions = FormatOptions.STANDARDBASELINE;
            options.matte = MatteType.WHITE;
            activeTask = "Zapisywanie JPG: " + file.name;
            if (file.exists) { throw new Error("W trakcie eksportu pojawił się plik o tej samej nazwie. Ponów eksport."); }
            renderDoc.saveAs(file, options, true, Extension.LOWERCASE);
            if (!file.exists || file.length <= 0) {
                throw new Error("Photoshop nie potwierdził zapisu pliku: " + file.fsName);
            }
        } finally {
            closeTemp(renderDoc, "JPG");
            renderDoc = null;
            app.activeDocument = work;
        }
    }

    function exportPlan(plan) {
        checkCancel();
        app.activeDocument = sourceDoc;
        activeTask = "Kopia obszaru: " + plan.board.name;
        showProgress(plan.board.name, "Przygotowywanie kopii dokumentu...");
        workingDoc = sourceDoc.duplicate("_SKUN_PRACA_TYMCZASOWA_", false);
        try {
            app.activeDocument = workingDoc;
            var board = isolateBoard(workingDoc, plan.board.path);
            // Read geometry in the duplicate, before artboard flattening changes origins.
            var rect = artboardRect(board);
            var sequence = 0;
            Core.eachVariant(plan.variables.length, plan.includeBase, function (combo) {
                checkCancel();
                sequence++;
                app.activeDocument = workingDoc;
                activeTask = "Ustawianie grup: " + plan.board.name;
                applyCombination(board, plan, combo);
                var names = groupNames(plan, combo);
                var stem = Core.filename(settings.prefix, plan.board.number,
                                         plan.board.name, sequence, names);
                var file = availableFile(settings.folder, stem);
                showProgress(plan.board.name, names.length ? names.join(" + ") : "Samo tło");
                saveVariant(workingDoc, rect, file, settings.quality);
                savedCount++;
                showProgress(plan.board.name, "Zapisano: " + file.name);
                return true;
            });
        } finally {
            closeTemp(workingDoc, "robocza");
            workingDoc = null;
            app.activeDocument = sourceDoc;
        }
    }

    function errorText(error) {
        var s = error && error.message ? error.message : String(error);
        if (error && error.number) { s += "\nNumer błędu: " + error.number; }
        if (error && error.line) { s += "\nWiersz skryptu: " + error.line; }
        return s;
    }

    function main() {
        if (!app.documents.length) { alert("Otwórz dokument z obszarami kompozycji.", TITLE); return; }
        sourceDoc = app.activeDocument;
        if (sourceDoc.bitsPerChannel === BitsPerChannelType.THIRTYTWO) {
            alert("Ten dokument ma 32 bity na kanał. Przygotuj kopię 8- lub 16-bitową przed eksportem JPG.", TITLE);
            return;
        }
        var boards = [];
        activeTask = "Odczytywanie obszarów kompozycji";
        collectArtboards(sourceDoc, [], boards);
        if (!boards.length) {
            alert("Nie znaleziono obszarów kompozycji. Skrypt wymaga obszaru kompozycji z osobnymi grupami dla tła i grafik zmiennych.", TITLE);
            return;
        }
        var plans = [];
        for (var i = 0; i < boards.length; i++) {
            var plan = configArtboard(boards[i], i + 1, boards.length);
            if (!plan) { return; }
            if (plan.skip) { continue; }
            plans.push(plan);
            totalCount += plan.count;
        }
        if (!plans.length) { return; }
        settings = outputDialog(plans, totalCount);
        if (!settings) { return; }

        oldUnits = app.preferences.rulerUnits;
        oldDialogs = app.displayDialogs;
        prefsChanged = true;
        app.preferences.rulerUnits = Units.PIXELS;
        app.displayDialogs = DialogModes.NO;
        progress = makeProgress(totalCount);
        for (i = 0; i < plans.length; i++) { exportPlan(plans[i]); }
    }

    try {
        main();
    } catch (e) {
        if ((e && e.skunCancelled) || (e && e.number === 8007)) { wasCancelled = true; }
        else { failure = e; }
    } finally {
        closeTemp(renderDoc, "JPG");
        closeTemp(workingDoc, "robocza");
        if (prefsChanged) {
            try { app.preferences.rulerUnits = oldUnits; } catch (ignoreUnits) {}
            try { app.displayDialogs = oldDialogs; } catch (ignoreDialogs) {}
        }
        if (sourceDoc) {
            try { app.activeDocument = sourceDoc; } catch (ignoreActiveDoc) {}
        }
        if (progress) {
            progress.allowClose = true;
            try { progress.close(); } catch (ignoreProgress) {}
        }
    }

    if (failure) {
        alert("Eksport został zatrzymany.\n\nEtap: " + activeTask + "\n" + errorText(failure) +
              "\n\nZapisano " + savedCount + " z " + totalCount + " JPG." +
              (settings ? "\nFolder: " + settings.folder.fsName : "") +
              (cleanupWarnings.length ? "\n\n" + cleanupWarnings.join("\n") : ""), TITLE);
    } else if (wasCancelled) {
        alert("Przerwano eksport. Zapisane wcześniej pliki pozostają w folderze.\n\nZapisano: " + savedCount +
              " z " + totalCount + " JPG." + (settings ? "\nFolder: " + settings.folder.fsName : "") +
              (cleanupWarnings.length ? "\n\n" + cleanupWarnings.join("\n") : ""), TITLE);
    } else if (settings) {
        alert("Gotowe! Zapisano " + savedCount + " JPG.\n\nFolder: " + settings.folder.fsName +
              (cleanupWarnings.length ? "\n\n" + cleanupWarnings.join("\n") : ""), TITLE);
    }
}());
