#target photoshop
app.bringToFront();

/*
 SKUN EXPRESS | Plotno i prowadnice v1.3
 Photoshop ExtendScript (.jsx)
 - ciecie: gorna, dolna, prawa (powiekszenie plotna)
 - grzbiet: lewa (powiekszenie plotna)
 - marginesy: 4 prowadnice wewnatrz pierwotnego formatu
 Prowadnice wstawiane sa po zmianie plotna, w pozycjach odpowiadajacych
 krawedziom oryginalnego dokumentu. Zapewnia to precyzyjne polozenie.
*/
(function () {
    if (app.documents.length === 0) {
        alert('Otworz dokument w Photoshopie i uruchom skrypt ponownie.');
        return;
    }

    var doc = app.activeDocument;
    var dlg = new Window('dialog', 'SKUN EXPRESS | Plotno i prowadnice');
    dlg.orientation = 'column';
    dlg.alignChildren = ['fill', 'top'];
    dlg.spacing = 11;
    dlg.margins = 18;

    dlg.add('statictext', undefined, 'Wpisz wartosci w milimetrach. Puste pole = pomin.');

    function makeField(label) {
        var row = dlg.add('group');
        row.orientation = 'row';
        row.alignChildren = ['left', 'center'];
        var txt = row.add('statictext', undefined, label);
        txt.preferredSize.width = 195;
        var edit = row.add('edittext', undefined, '');
        edit.characters = 12;
        row.add('statictext', undefined, 'mm');
        return edit;
    }

    var cutField = makeField('Linie ciecia (gora, dol, prawa)');
    var spineField = makeField('Grubosc grzbietu (lewa)');
    var marginField = makeField('Marginesy (4 strony)');

    var resizeOption = dlg.add('checkbox', undefined, 'Zmien rozmiar plotna');
    resizeOption.value = true;

    var legend = dlg.add('statictext', undefined,
        'Kolory: ciecie - neonowy roz | grzbiet - neonowa zielen | marginesy - neonowy zolty.');
    var info = dlg.add('statictext', undefined,
        'Skrypt powiekszy plotno, nie skaluje projektu.', { multiline: true });
    info.preferredSize.width = 390;
    resizeOption.onClick = function () {
        info.text = resizeOption.value
            ? 'Skrypt powiekszy plotno, nie skaluje projektu.'
            : 'Tylko prowadnice: odleglosci liczone od aktualnych krawedzi plotna.';
    };

    var buttons = dlg.add('group');
    buttons.alignment = 'right';
    var cancel = buttons.add('button', undefined, 'Anuluj', { name: 'cancel' });
    var accept = buttons.add('button', undefined, 'Zastosuj', { name: 'ok' });

    function readMM(field, fieldName) {
        var raw = field.text.replace(/^\s+|\s+$/g, '').replace(',', '.');
        if (raw === '') return null;
        if (!/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(raw)) {
            throw new Error('Nieprawidlowa wartosc: ' + fieldName + '. Wpisz liczbe >= 0.');
        }
        var num = Number(raw);
        if (!isFinite(num) || num < 0) {
            throw new Error('Nieprawidlowa wartosc: ' + fieldName + '.');
        }
        return num;
    }

    var params = null;
    accept.onClick = function () {
        try {
            var cut = readMM(cutField, 'linie ciecia');
            var spine = readMM(spineField, 'grubosc grzbietu');
            var margin = readMM(marginField, 'marginesy');
            if (cut === null && spine === null && margin === null) {
                alert('Podaj przynajmniej jedna wartosc.');
                return;
            }
            params = { cut: cut, spine: spine, margin: margin, resize: resizeOption.value };
            dlg.close(1);
        } catch (e) {
            alert(e.message);
        }
    };
    cancel.onClick = function () { dlg.close(0); };
    if (dlg.show() !== 1 || params === null) return;

    var originalRuler = app.preferences.rulerUnits;
    var originalDialog = app.displayDialogs;
    try {
        app.preferences.rulerUnits = Units.PIXELS;
        app.displayDialogs = DialogModes.NO;

        var dpi = doc.resolution;
        var origW = Math.round(doc.width.as('px'));
        var origH = Math.round(doc.height.as('px'));
        function mmToPx(mm) { return Math.round(mm * dpi / 25.4); }
        var cutPx = params.cut === null ? 0 : mmToPx(params.cut);
        var spinePx = params.spine === null ? 0 : mmToPx(params.spine);
        var marginPx = params.margin === null ? 0 : mmToPx(params.margin);

        if (params.margin !== null && (2 * marginPx >= origW || 2 * marginPx >= origH)) {
            throw new Error('Marginesy sa za duze w stosunku do pierwotnego formatu.');
        }
        if (!params.resize) {
            if (params.cut !== null && (cutPx > origH / 2 || cutPx > origW))
                throw new Error('Linie ciecia wykraczaja poza aktualne plotno.');
            if (params.spine !== null && spinePx > origW)
                throw new Error('Linia grzbietu wykracza poza aktualne plotno.');
        }

        // Zmieniaj tylko plotno, bez skalowania warstw.
        // Kazda operacja powieksza dokladnie jedna wskazana strone.
        if (params.resize && spinePx > 0) {
            doc.resizeCanvas(UnitValue(origW + spinePx, 'px'),
                UnitValue(origH, 'px'), AnchorPosition.MIDDLERIGHT);
        }
        if (params.resize && cutPx > 0) {
            doc.resizeCanvas(UnitValue(origW + spinePx + cutPx, 'px'),
                UnitValue(origH, 'px'), AnchorPosition.MIDDLELEFT);
            doc.resizeCanvas(UnitValue(origW + spinePx + cutPx, 'px'),
                UnitValue(origH + cutPx, 'px'), AnchorPosition.BOTTOMCENTER);
            doc.resizeCanvas(UnitValue(origW + spinePx + cutPx, 'px'),
                UnitValue(origH + 2 * cutPx, 'px'), AnchorPosition.TOPCENTER);
        }

        // Po powiekszeniu pierwotny format zaczyna sie w (spinePx, cutPx).
        // Prowadnice dodajemy po przeliczeniu pozycji dla NOWEGO plotna,
        // aby nie polegac na sposobie przesuwania prowadnic przez Photoshop.
        // Kolorowe prowadnice przez Photoshop Action Manager.
        // Deskryptor odpowiada akcji "Nowa linia pomocnicza" z obsluga RGB.
        var colorProblems = 0;
        function addColoredGuide(vertical, pos, rgb) {
            try {
                var s2t = stringIDToTypeID;
                var c2t = charIDToTypeID;
                var cmd = new ActionDescriptor();
                var guide = new ActionDescriptor();
                var ref = new ActionReference();
                ref.putClass(s2t('good'));
                cmd.putReference(s2t('null'), ref);
                guide.putUnitDouble(s2t('position'), s2t('pixelsUnit'), pos);
                guide.putEnumerated(s2t('orientation'), s2t('orientation'),
                    s2t(vertical ? 'vertical' : 'horizontal'));
                guide.putEnumerated(s2t('kind'), s2t('kind'), s2t('document'));
                guide.putInteger(c2t('GdCR'), rgb[0]);
                guide.putInteger(c2t('GdCG'), rgb[1]);
                guide.putInteger(c2t('GdCB'), rgb[2]);
                guide.putInteger(c2t('GdCA'), 0);
                cmd.putObject(s2t('new'), s2t('good'), guide);
                cmd.putEnumerated(s2t('guideTarget'), s2t('guideTarget'),
                    s2t('guideTargetCanvas'));
                executeAction(s2t('make'), cmd, DialogModes.NO);
            } catch (colorError) {
                // Awaryjnie dodaj prowadnice w kolorze domyslnym.
                colorProblems++;
                doc.guides.add(vertical ? Direction.VERTICAL : Direction.HORIZONTAL,
                    UnitValue(pos, 'px'));
            }
        }
        function v(x, color) { addColoredGuide(true, x, color); }
        function h(y, color) { addColoredGuide(false, y, color); }
        var RED = [253, 74, 255];   // #FD4AFF
        var GREEN = [100, 255, 74]; // #64FF4A
        var BLUE = [255, 246, 0];  // #FFF600

        // Tryb powiekszania: prowadnice na granicy oryginalnego obszaru.
        // Tryb bez powiekszania: prowadnice przesuniete do wewnatrz od
        // AKTUALNYCH krawedzi o wartosci wskazane w oknie.
        var left = params.resize ? spinePx : 0;
        var top = params.resize ? cutPx : 0;
        var right = left + origW;
        var bottom = top + origH;
        var cutTop = params.resize ? top : cutPx;
        var cutBottom = params.resize ? bottom : origH - cutPx;
        var cutRight = params.resize ? right : origW - cutPx;
        var spineLeft = params.resize ? left : spinePx;

        if (params.cut !== null) {
            h(cutTop, RED);       // ciecie gorne
            h(cutBottom, RED);    // ciecie dolne
            v(cutRight, RED);     // ciecie prawe
        }
        if (params.spine !== null) {
            v(spineLeft, GREEN);  // granica grzbietu po lewej
        }
        if (params.margin !== null) {
            v(left + marginPx, BLUE);
            v(right - marginPx, BLUE);
            h(top + marginPx, BLUE);
            h(bottom - marginPx, BLUE);
        }
        if (colorProblems > 0) {
            alert('Dodano prowadnice, ale ' + colorProblems +
                ' z nich ma kolor domyslny (Photoshop odrzucil kolor niestandardowy).');
        }
    } catch (err) {
        alert('SKUN EXPRESS - blad: ' + err.message + (params.resize ? '\n\nJesli zmieniono plotno, uzyj Ctrl+Z, aby cofnac ostatnia operacje.' : ''));
    } finally {
        app.preferences.rulerUnits = originalRuler;
        app.displayDialogs = originalDialog;
    }
})();
