﻿#target photoshop
/*
 SQN Export Artboards — ExtendScript / JSX
 Eksport dokladnych wymiarow obszarow kompozycji: JPG domyslnie, wybrane PNG.
 Nie modyfikuje pliku zrodlowego.
*/
(function () {
    if (app.documents.length === 0) {
        alert("Otworz dokument PSD z obszarami kompozycji.");
        return;
    }

    var original = app.activeDocument;
    var oldDialogs = app.displayDialogs;
    var oldUnits = app.preferences.rulerUnits;
    var s2t = stringIDToTypeID;
    var boards = [];

    function amNumber(desc, key) {
        try { return desc.getDouble(s2t(key)); } catch (e1) {}
        try { return desc.getUnitDoubleValue(s2t(key)); } catch (e2) {}
        throw new Error("Nie mozna odczytac wspolrzednej: " + key);
    }
    function isArtboard(layer) {
        if (layer.typename !== "LayerSet") return false;
        try {
            var ref = new ActionReference();
            ref.putProperty(s2t("property"), s2t("artboardEnabled"));
            ref.putIdentifier(s2t("layer"), layer.id);
            var d = executeActionGet(ref);
            return d.hasKey(s2t("artboardEnabled")) && d.getBoolean(s2t("artboardEnabled"));
        } catch (e) { return false; }
    }
    function artboardRect(layer) {
        var ref = new ActionReference();
        ref.putProperty(s2t("property"), s2t("artboard"));
        ref.putIdentifier(s2t("layer"), layer.id);
        var d = executeActionGet(ref).getObjectValue(s2t("artboard"))
            .getObjectValue(s2t("artboardRect"));
        return [amNumber(d, "left"), amNumber(d, "top"),
                amNumber(d, "right"), amNumber(d, "bottom")];
    }
    function safeName(name) {
        var s = String(name).replace(/[\\\/:*?"<>|\x00-\x1f]/g, "_")
            .replace(/[. ]+$/g, "");
        return s.length ? s : "Kompozycja";
    }
    function outputFile(folder, baseName, ext) {
        var path = folder.fsName + "/" + baseName + "." + ext;
        var candidate = new File(path), index = 2;
        while (candidate.exists) {
            candidate = new File(folder.fsName + "/" + baseName + "_" + index + "." + ext);
            index++;
        }
        return candidate;
    }
    function exportBoard(board, usePNG, prefix, folder) {
        var working = null;
        var exported = null;
        try {
            app.activeDocument = original;
            working = original.duplicate("SQN_EXPORT_SOURCE_" + (board.index + 1), false);
            app.activeDocument = working;

            // Only render the selected artboard on the temporary source copy.
            var target = null;
            for (var j = 0; j < working.layers.length; j++) {
                var layer = working.layers[j];
                if (j === board.index) {
                    target = layer;
                    layer.visible = true;
                } else {
                    layer.visible = false;
                }
            }
            if (!target || target.typename !== "LayerSet") {
                throw new Error("Nie odnaleziono obszaru w kopii dokumentu.");
            }

            var left = Math.round(board.rect[0]);
            var top = Math.round(board.rect[1]);
            var right = Math.round(board.rect[2]);
            var bottom = Math.round(board.rect[3]);
            var width = right - left;
            var height = bottom - top;
            if (width <= 0 || height <= 0) {
                throw new Error("Obszar kompozycji ma nieprawidlowe wymiary.");
            }

            // Photoshop's crop() is unreliable while the document contains
            // native artboards: it may export the entire document canvas.
            // Copy ONLY the pixel selection of this artboard to a NEW document
            // with exactly the artboard's width and height.
            working.selection.select([
                [left, top], [right, top], [right, bottom], [left, bottom]
            ], SelectionType.REPLACE, 0, false);
            var hasPixels = true;
            try {
                working.selection.copy(true); // true = Copy Merged
            } catch (copyError) {
                // A completely transparent/empty artboard has nothing to copy.
                hasPixels = false;
            }
            working.selection.deselect();

            exported = app.documents.add(
                UnitValue(width, "px"), UnitValue(height, "px"),
                original.resolution, "SQN_EXPORT_RESULT", NewDocumentMode.RGB,
                DocumentFill.TRANSPARENT, 1, original.bitsPerChannel
            );
            app.activeDocument = exported;
            if (hasPixels) {
                exported.paste();
            }

            var opts = new ExportOptionsSaveForWeb();
            if (usePNG) {
                opts.format = SaveDocumentType.PNG;
                opts.PNG8 = false;
                opts.transparency = true;
                opts.interlaced = false;
            } else {
                // Explicit white backdrop for JPG instead of relying on the
                // Photoshop user's current background color.
                var whiteLayer = exported.artLayers.add();
                whiteLayer.name = "JPG - biale tlo";
                if (exported.layers.length > 1) {
                    whiteLayer.move(exported.layers[exported.layers.length - 1], ElementPlacement.PLACEAFTER);
                }
                exported.activeLayer = whiteLayer;
                var white = new SolidColor();
                white.rgb.red = 255;
                white.rgb.green = 255;
                white.rgb.blue = 255;
                exported.selection.selectAll();
                exported.selection.fill(white);
                exported.selection.deselect();
                exported.flatten();
                opts.format = SaveDocumentType.JPEG;
                opts.quality = 90;
                opts.optimized = true;
            }
            var ext = usePNG ? "png" : "jpg";
            var file = outputFile(folder, safeName(prefix + board.name), ext);
            exported.exportDocument(file, ExportType.SAVEFORWEB, opts);
            return file.name;
        } finally {
            if (exported !== null) {
                try { exported.close(SaveOptions.DONOTSAVECHANGES); } catch (e1) {}
            }
            if (working !== null) {
                try { working.close(SaveOptions.DONOTSAVECHANGES); } catch (e2) {}
            }
            app.activeDocument = original;
        }
    }

    try {
        app.preferences.rulerUnits = Units.PIXELS;
        for (var i = 0; i < original.layers.length; i++) {
            var layer = original.layers[i];
            if (!isArtboard(layer)) continue;
            boards.push({index: i, name: layer.name, rect: artboardRect(layer)});
        }
        if (boards.length === 0) {
            alert("Nie znaleziono obszarow kompozycji (Artboards) na glownym poziomie dokumentu.");
            return;
        }

        var win = new Window("dialog", "SQN | Eksport obszarow kompozycji");
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 12;
        win.margins = 18;

        win.add("statictext", undefined, "Tytul ksiazki (prefiks plikow):");
        var prefixInput = win.add("edittext", undefined, "");
        prefixInput.characters = 38;
        prefixInput.active = true;

        var panel = win.add("panel", undefined, "Obszary do eksportu (PNG / JPG)");
        panel.orientation = "column";
        panel.alignChildren = ["fill", "top"];
        panel.margins = 12;
        panel.spacing = 5;
        panel.preferredSize.width = 475;

        panel.add("statictext", undefined, "Zaznacz PNG. Brak zaznaczenia = JPG. X = pomin obszar.");
        var rowsHolder = panel.add("group");
        rowsHolder.orientation = "column";
        rowsHolder.alignChildren = ["fill", "top"];
        rowsHolder.spacing = 3;

        var included = [], pngFlags = [];
        for (var n = 0; n < boards.length; n++) {
            included[n] = true;
            pngFlags[n] = false;
        }

        // Pokazujemy maksymalnie 10 obszarow naraz. Stronicowanie
        // pozwala uzywac przyciskow X takze w duzych dokumentach.
        var page = 0;
        var perPage = 10;
        var nav = panel.add("group");
        nav.alignment = "fill";
        var prevBtn = nav.add("button", undefined, "< Poprzednie");
        var pageLabel = nav.add("statictext", undefined, "");
        pageLabel.alignment = ["fill", "center"];
        var nextBtn = nav.add("button", undefined, "Nastepne >");

        var tools = win.add("group");
        tools.alignment = "left";
        var allBtn = tools.add("button", undefined, "Wszystkie PNG");
        var noneBtn = tools.add("button", undefined, "Wszystkie JPG");
        var restoreBtn = tools.add("button", undefined, "Przywroc pominiete");

        function activeIndices() {
            var result = [];
            for (var i = 0; i < boards.length; i++) {
                if (included[i]) result.push(i);
            }
            return result;
        }
        function updateRows() {
            // Usuwanie starych wierszy nie modyfikuje dokumentu PSD.
            while (rowsHolder.children.length) rowsHolder.remove(rowsHolder.children[0]);
            var active = activeIndices();
            var pages = Math.max(1, Math.ceil(active.length / perPage));
            if (page >= pages) page = pages - 1;
            var first = page * perPage;
            var last = Math.min(first + perPage, active.length);

            if (active.length === 0) {
                rowsHolder.add("statictext", undefined, "Wszystkie obszary zostaly pominiete.");
            }
            for (var j = first; j < last; j++) {
                (function (idx) {
                    var row = rowsHolder.add("group");
                    row.orientation = "row";
                    row.alignChildren = ["left", "center"];
                    row.spacing = 7;
                    var cb = row.add("checkbox", undefined, "PNG");
                    cb.value = pngFlags[idx];
                    cb.onClick = function () { pngFlags[idx] = cb.value; };
                    var name = row.add("statictext", undefined, boards[idx].name);
                    name.preferredSize.width = 315;
                    var removeBtn = row.add("button", undefined, "X");
                    removeBtn.preferredSize = [28, 24];
                    removeBtn.helpTip = "Pomin ten obszar przy eksporcie (nie usuwa z PSD)";
                    removeBtn.onClick = function () {
                        included[idx] = false;
                        updateRows();
                    };
                })(active[j]);
            }
            pageLabel.text = "Strona " + (page + 1) + "/" + pages +
                "  |  Do eksportu: " + active.length + "/" + boards.length;
            prevBtn.enabled = page > 0;
            nextBtn.enabled = page < pages - 1;
            // ScriptUI potrzebuje ponownego przeliczenia rozmiaru po zmianie wierszy.
            win.layout.layout(true);
            win.layout.resize();
        }
        prevBtn.onClick = function () { page--; updateRows(); };
        nextBtn.onClick = function () { page++; updateRows(); };
        allBtn.onClick = function () {
            for (var i = 0; i < boards.length; i++) if (included[i]) pngFlags[i] = true;
            updateRows();
        };
        noneBtn.onClick = function () {
            for (var i = 0; i < boards.length; i++) if (included[i]) pngFlags[i] = false;
            updateRows();
        };
        restoreBtn.onClick = function () {
            for (var i = 0; i < boards.length; i++) included[i] = true;
            page = 0;
            updateRows();
        };

        var bottom = win.add("group");
        bottom.alignment = "right";
        bottom.add("button", undefined, "Anuluj", {name: "cancel"});
        // Zwykly przycisk: nie uzywamy {name: "ok"}, bo ScriptUI
        // zamkneloby okno przed sprawdzeniem tytulu.
        var exportBtn = bottom.add("button", undefined, "Eksportuj...");
        exportBtn.onClick = function () {
            var title = prefixInput.text.replace(/^\s+|\s+$/g, "");
            if (!title.length) {
                alert("Wpisz tytul ksiazki przed eksportem.");
                prefixInput.active = true;
                return; // Okno pozostaje otwarte.
            }
            if (activeIndices().length === 0) {
                alert("Wybierz co najmniej jeden obszar do eksportu.");
                return; // Okno pozostaje otwarte.
            }
            win.close(1);
        };
        updateRows();
        if (win.show() !== 1) return;

        var activeBoards = activeIndices();
        var title = prefixInput.text.replace(/^\s+|\s+$/g, "");
        var prefix = safeName(title) + "_";
        var folder = Folder.selectDialog("Wybierz folder do zapisu JPG i PNG");
        if (folder === null) return;

        app.displayDialogs = DialogModes.NO;
        var ok = 0, failures = [];
        for (var k = 0; k < activeBoards.length; k++) {
            var idx = activeBoards[k];
            try {
                exportBoard(boards[idx], pngFlags[idx], prefix, folder);
                ok++;
            } catch (err) {
                failures.push(boards[idx].name + ": " + err.message);
            }
        }
        var summary = "Zapisano " + ok + " z " + activeBoards.length + " wybranych obszarow.\nFolder: " + folder.fsName;
        if (failures.length) summary += "\n\nBledy:\n" + failures.join("\n");
        alert(summary);
    } catch (fatal) {
        alert("Blad skryptu: " + fatal.message + (fatal.line ? " (linia " + fatal.line + ")" : ""));
    } finally {
        app.displayDialogs = oldDialogs;
        app.preferences.rulerUnits = oldUnits;
        try { app.activeDocument = original; } catch (ignore) {}
    }
})();
