﻿// Lista wysokości do eksportu
var sizes = [1500, 1000, 500, 300, 200, 100];

// Pobierz oryginalny dokument
var originalDoc = app.activeDocument;
var originalName = originalDoc.name.replace(/\.[^\.]+$/, ""); // bez rozszerzenia

// Wpisz prefiks nazw eksportowanych plików
var exportPrefix = prompt("Wpisz nazwę (prefiks) dla eksportowanych plików:", "");

// Wybierz folder zapisu
var saveFolder = null;
if (exportPrefix !== null) {
    saveFolder = Folder.selectDialog("Wybierz folder do eksportu plików JPG");
}

// Iteracja po rozmiarach
if (exportPrefix !== null && saveFolder !== null) {
for (var i = 0; i < sizes.length; i++) {
    var newHeight = sizes[i];

    // Duplikuj dokument
    var newDoc = originalDoc.duplicate(originalName + "_" + newHeight + "px", true);

    // Zmień rozmiar proporcjonalnie
    var aspectRatio = newDoc.width / newDoc.height;
    var newWidth = newHeight * aspectRatio;

    newDoc.resizeImage(UnitValue(newWidth, "px"), UnitValue(newHeight, "px"), null, ResampleMethod.BICUBIC);

    // Ustal nazwę pliku
    var saveName = exportPrefix + "_okladka_" + newHeight + "px.jpg";
    var saveFile = new File(saveFolder + "/" + saveName);

    // Zapisz jako JPG
    var jpgOptions = new JPEGSaveOptions();
    jpgOptions.quality = 12; // max jakość

    newDoc.saveAs(saveFile, jpgOptions, true, Extension.LOWERCASE);
    newDoc.close(SaveOptions.DONOTSAVECHANGES);
}

alert("Gotowe! Obrazy zapisane w:\n" + saveFolder);
}
