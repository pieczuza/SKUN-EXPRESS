#target photoshop

// Funkcja sprawdzająca, czy dokument jest otwarty
function checkDocumentOpen() {
    if (app.documents.length === 0) {
        alert("Brak otwartego dokumentu! Proszę otworzyć dokument, aby kontynuować.");
        return false;
    }
    return true;
}

// Funkcja do otwierania folderu C:\Users\Lenovo\Documents\Media lub Pulpit
function openFolder() {
    var mediaFolder = new Folder("C:/Users/Lenovo/Documents/Media");
    if (!mediaFolder.exists) {
        var desktop = new Folder("~/Desktop");
        desktop.execute();
        return null;
    }
    mediaFolder.execute();
    return mediaFolder;
}

// Funkcja zmieniająca szerokość obrazu na podstawie wprowadzonych danych
function resizeDocument() {
    if (!checkDocumentOpen()) return;

    var doc = app.activeDocument;

    // Tworzenie okna dialogowego z przyciskami dla domyślnych wymiarów
    var dialog = new Window("dialog", "Wybierz wymiary książki");

    // Przyciski z domyślnymi wymiarami
    var defaultSize = "140x205"; // Domyślny wybór
    dialog.defaultDimensions = defaultSize;
    var buttonGroup = dialog.add("group", undefined, "buttonGroup");
    buttonGroup.orientation = "row";

    var button140x205 = buttonGroup.add("button", undefined, "140x205");
    var button150x205 = buttonGroup.add("button", undefined, "150x205");
    var button150x215 = buttonGroup.add("button", undefined, "150x215");
    var button120x205 = buttonGroup.add("button", undefined, "120x205");
    var button165x215 = buttonGroup.add("button", undefined, "165x215 (Tappi)");

    // Pole tekstowe do wpisania niestandardowego rozmiaru
    var inputGroup = dialog.add("group");
    inputGroup.add("statictext", undefined, "Niestandardowy rozmiar (szerokość x wysokość):");
    var inputField = inputGroup.add("edittext", undefined, defaultSize);
    inputField.characters = 10;

    // Dodanie przycisku "OK"
    var okButton = dialog.add("button", undefined, "OK");

    // Przypisanie akcji do przycisków
    button140x205.onClick = function () { dialog.defaultDimensions = "140x205"; };
    button150x205.onClick = function () { dialog.defaultDimensions = "150x205"; };
    button150x215.onClick = function () { dialog.defaultDimensions = "150x215"; };
    button120x205.onClick = function () { dialog.defaultDimensions = "120x205"; };
    button165x215.onClick = function () { dialog.defaultDimensions = "165x215 (Tappi)"; };

    // Akcja przycisku OK
    okButton.onClick = function () {
        dialog.defaultDimensions = inputField.text;
        dialog.close();
    };

    dialog.show();

    var selectedSize = dialog.defaultDimensions;

    // Rozdzielenie wartości szerokości i wysokości
    var dimensions = selectedSize.split("x");
    var widthFormat = parseFloat(dimensions[0].replace(/^\s+|\s+$/g, ''));
    var heightFormat = parseFloat(dimensions[1].replace(/^\s+|\s+$/g, ''));

    if (isNaN(widthFormat) || isNaN(heightFormat)) {
        alert("Wprowadź prawidłowe liczby.");
        return;
    }

    // Obliczenie ratio formatu
    var ratio = widthFormat / heightFormat;

    // Pobranie aktualnej wysokości dokumentu
    var docHeight = doc.height.as("px");

    // Obliczenie nowej szerokości na podstawie wysokości dokumentu
    var newWidth = docHeight * ratio;

    // Zmiana rozmiaru obrazu
    doc.resizeImage(newWidth, docHeight);

    // Wyświetlenie komunikatu z nowymi wymiarami
    alert("Nowe wymiary dokumentu: Szerokość: " + newWidth.toFixed(2) + " px, Wysokość: " + docHeight.toFixed(2) + " px.");

    // Wybór obrazu do wklejenia
    var file = File.openDialog("Wybierz obraz do wklejenia");
    if (file) {
        var newImage = app.open(file); // Otwiera wybrany obraz

        // Skalowanie obrazu do wysokości 1500px, zachowując proporcje
        var scalingFactor = 1500 / newImage.height.as("px");
        newImage.resizeImage(newImage.width.as("px") * scalingFactor, 1500); // Zmiana tylko wysokości

        var newLayer = newImage.artLayers[0]; // Pierwsza warstwa nowego obrazu

        // Skopiowanie nowej warstwy
        newLayer.copy();

        // Uaktywnienie dokumentu docelowego przed wklejeniem
        app.activeDocument = doc;

        // Wklejenie skopiowanej warstwy do aktywnego dokumentu
        doc.paste();

        // Ustawienie wklejonej warstwy w oryginalnym rozmiarze (w razie potrzeby)
        var pastedLayer = doc.activeLayer;

        // Sprawdzamy, czy w dokumencie jest warstwa o nazwie "1"
        var targetLayer = null;
        for (var i = 0; i < doc.artLayers.length; i++) {
            if (doc.artLayers[i].name === "1") {
                targetLayer = doc.artLayers[i];
                break;
            }
        }

        // Jeśli warstwa "1" została znaleziona
        if (targetLayer) {
            // Wklejona warstwa powinna być czwórką, więc umieszczamy ją przed warstwą "1"
            pastedLayer.move(targetLayer, ElementPlacement.PLACEBEFORE); // Przenosimy wklejoną warstwę przed warstwą "1"
            alert('Nowa warstwa została umieszczona przed warstwą "1", włącz maskę przycinającą.');
        } else {
            alert('Nie znaleziono warstwy o nazwie "1".');
        }

        // Zamknięcie nowego obrazu (nie zapisuje go)
        newImage.close(SaveOptions.DONOTSAVECHANGES);
    }
}

// Uruchomienie funkcji
resizeDocument();